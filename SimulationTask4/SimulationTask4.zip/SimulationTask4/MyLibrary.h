#include<bits/stdc++.h>
using namespace std;

void simulateUtil(int l , int h , int N , int dh , int dl , int stisq , int stcq , queue<pair<int , pair<double , double> > > packets , vector<double> totalTime , int batchSize);